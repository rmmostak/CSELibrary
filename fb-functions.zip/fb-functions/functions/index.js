//import firebase functions modules
const functions = require('firebase-functions');
//import admin module
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);


// Listens for new messages added to messages/:pushId
exports.pushNotification = functions.database.ref('/Books List/').onWrite(event => {

	//const original = snapshot.val();


    console.log('Push notification event triggered');
  
  payload = {notification: {
                                 title: 'A new Book is Available!!',
                                 body: 'Please, check app for details!!',
                                 color: '#FFFFFF',
                                 sound: 'default',
                                 //tag: 'tomorrowEdit',

                                 }
                             };

  //Create an options object that contains the time to live for the notification and the priority
    //const options = {
       // priority: "high",
       // timeToLive: 60 * 60 * 24
		
		
    //};


    return admin.messaging().sendToTopic("rm", payload);
});